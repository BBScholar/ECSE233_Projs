The jar file and class files are in the out/ directory

While in the out/ directory, you can run the program with either
1) java Demo
2) chmod +x demo.jar && ./demo.jar
