The class files are in the out/ directory
run with "cd out && java Demo"
