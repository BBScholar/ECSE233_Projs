
Compile with 'javac *.java'
Run the test harness with 'java A2P1 <filename> <dimension> <search value>'

Run test file with 'java Test'. This will otuput the average runtimes in a csv.

Run the plotting script with 'python3 plot.py', this will generate the regression line stats and a plot.
