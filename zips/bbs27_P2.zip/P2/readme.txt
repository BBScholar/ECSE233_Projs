
Compile with 'javac *.java'
Run the test harness with 'java A2P1 <filename> <dimension> <search value>'
