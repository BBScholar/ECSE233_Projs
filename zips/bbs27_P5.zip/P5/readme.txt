run `java -ea Main` to run the main test method with assertions
run `java AVLTreeTest` to test the base AVLTree class
